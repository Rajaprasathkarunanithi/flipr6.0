package com.rajaprasath.covid.data;

import android.util.Log;

import androidx.annotation.NonNull;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.rajaprasath.covid.ContactNHelpline;
import com.rajaprasath.covid.Deceased;
import com.rajaprasath.covid.HospitalBeds;
import com.rajaprasath.covid.MainActivity;
import com.rajaprasath.covid.MedicalBeds;
import com.rajaprasath.covid.NotifNAdvisory;
import com.rajaprasath.covid.R;
import com.rajaprasath.covid.model.Category;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class CoronaApi {
    public List<Category> cont_help = new ArrayList<>();
    public List<Category> notif_adv = new ArrayList<>();
    public List<Category> hosp_bed= new ArrayList<>();
    public List<Category> medicol_bed=new ArrayList<>();

    public List<Category> Contact_N_Helpline(ContactNHelpline Activity, final AsyncResponse callback) {

        RequestQueue queue= VolleySingleton.getInstance(Activity).getRequestQueue();


        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, "https://api.rootnet.in/covid19-in/contacts", (JSONObject) null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONObject("data").getJSONObject("contacts").getJSONArray("regional");
                    for (int i=0;i<array.length();i++){
                        Category category = new Category();
                        category.setState(response.getJSONObject("data").getJSONObject("contacts").getJSONArray("regional").getJSONObject(i).getString("loc"));
                        category.setHelpline(response.getJSONObject("data").getJSONObject("contacts").getJSONArray("regional").getJSONObject(i).getString("number"));
                        cont_help.add(category);
                       // Log.d("x", "onResponse: "+category.getState());
                     //   Log.d("array", "onResponse: "+response.getJSONObject("data").getJSONObject("contacts").getJSONArray("regional").getJSONObject(i).getString("loc"));
                    }
                    if(callback!=null){
                        callback.processFinished((ArrayList<Category>) cont_help);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }

        });
        queue.add(jsonObjectRequest);

        return cont_help;
    }

    public List<Category> Notif_N_Advisory(NotifNAdvisory Activity, final AsyncResponse callback) {
        RequestQueue queue= VolleySingleton.getInstance(Activity).getRequestQueue();

        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, "https://api.rootnet.in/covid19-in/notifications", (JSONObject) null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {

                    JSONArray array =response.getJSONObject("data").getJSONArray("notifications");

                    for (int i=1 ; i<array.length();i++){
                        Category category = new Category();
                      //  Log.d("estt", "onResponse: "+response.getJSONObject("data").getJSONArray("notifications").getJSONObject(i).getString("title"));
                           String string =response.getJSONObject("data").getJSONArray("notifications").getJSONObject(i).getString("title");
                          String[] arrofStr = string.split(" ",2);

                          category.setDate(arrofStr[0]);
                          category.setNotification_title(arrofStr[1]);
                          category.setLink(response.getJSONObject("data").getJSONArray("notifications").getJSONObject(i).getString("link"));
                          notif_adv.add(category);
                        }
                    if(callback!=null){
                        callback.processFinished((ArrayList<Category>) notif_adv);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }

        });
        queue.add(jsonObjectRequest);
        return notif_adv;
    }

    public List<Category> Hosp_N_Beds(HospitalBeds Activity, final AsyncResponse callback) {
        RequestQueue queue= VolleySingleton.getInstance(Activity).getRequestQueue();

        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, "https://api.rootnet.in/covid19-in/hospitals/beds", (JSONObject) null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                   // Log.d("testt", "onResponse: "+response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getString("state"));
                    JSONArray array=response.getJSONObject("data").getJSONArray("regional");
                        for(int i=0;i<array.length();i++){
                            Category category= new Category();
                            category.setState(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getString("state"));
                            category.setRural_hosp(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getInt("ruralHospitals"));
                            category.setRural_beds(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getInt("ruralBeds"));
                            category.setUrban_hosp(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getInt("urbanHospitals"));
                            category.setUrban_beds(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getInt("urbanBeds"));
                            category.setTotal_hosp(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getInt("totalHospitals"));
                            category.setTotal_beds(response.getJSONObject("data").getJSONArray("regional").getJSONObject(i).getInt("totalBeds"));
                            Log.d("lll", "onResponse: "+category.getState());
                            hosp_bed.add(category);

                        }
                    //Log.d("tlog", "onResponse: "+hosp_bed);
                        if(callback!=null){
                            callback.processFinished((ArrayList<Category>) hosp_bed);
                        }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }

        });
        queue.add(jsonObjectRequest);
        return  hosp_bed;
    }


    public List<Category> Medicol_N_Beds(MedicalBeds Activity, final  AsyncResponse callback) {
        RequestQueue queue= VolleySingleton.getInstance(Activity).getRequestQueue();

        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, "https://api.rootnet.in/covid19-in/hospitals/medical-colleges", (JSONObject) null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray array= response.getJSONObject("data").getJSONArray("medicalColleges");
                 //   Log.d("estt", "onResponse: "+response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getString("state"));
                    for (int i=0;i<array.length();i++){
                         Category category=new Category();
                         category.setState(response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getString("state"));
                         category.setInstitute_name(response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getString("name"));
                         category.setCity(response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getString("city"));
                         category.setType(response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getString("ownership"));
                         category.setAdmission_capacity(response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getInt("admissionCapacity"));
                         category.setHospital_beds(response.getJSONObject("data").getJSONArray("medicalColleges").getJSONObject(i).getInt("hospitalBeds"));
                         medicol_bed.add(category);
                    }
                    if (callback!=null){
                        callback.processFinished((ArrayList<Category>) medicol_bed);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }

        });
        queue.add(jsonObjectRequest);
        return null;
    }


   // public List<Category> DeceasedPerson(Deceased Activity)





}
