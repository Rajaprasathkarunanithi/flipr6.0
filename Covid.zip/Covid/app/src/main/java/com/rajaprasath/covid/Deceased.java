package com.rajaprasath.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.rajaprasath.covid.data.DatabaseHandler;
import com.rajaprasath.covid.model.Category;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class Deceased extends AppCompatActivity {
   public List<Category> DeceasedPersons;
   ProgressBar progressBar;

    DatabaseHandler db = new DatabaseHandler(Deceased.this);
    private int y=0;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deceased);
        progressBar=findViewById(R.id.progressBar2);
        GraphView graph = (GraphView) findViewById(R.id.graph);
       new DbAsyn().execute();
        List<Category> Categorylist= db.getAllPerson();


        for (Category category: Categorylist)
        {
            Log.d("dttt", "onCreate: "+category.getState());
            if (category.getStatus()=="Hospitalized"){
                y++;}
            LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[] {

                    new DataPoint(Double.parseDouble(category.getDate()), y)
            });
            graph.addSeries(series);
        }



    }

    private void storeinDatabase(List<Category> DeceasedPersons) {
       // progressBar.setVisibility(View.VISIBLE);
        int i=0;
        for (Category category: DeceasedPersons){
            Log.d("ease", "storeinDatabase:"+i+" "+category.getStatus());
            i++;
            db.addPerson(category);
        }
      //  progressBar.setVisibility(View.GONE);
    }


    public List<Category> getcsv(){
        List<Category> deceased_persons= new ArrayList<>();
        InputStream is= getResources().openRawResource(R.raw.covid19india);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
        String line="";
        try {
            reader.readLine();
            int i=0;
            while ((line=reader.readLine())!=null&& i<=5000){
                String[] tokens= line.split(",");
                Category category= new Category();
                if(tokens.length>=11 && tokens[7].length()>0){
                    category.setState(tokens[7]);}
                if(tokens.length>=11 && tokens[0].length()>0){
                    category.setPatient_id(Integer.parseInt(tokens[0]));}
                if(tokens.length>=11 && tokens[3].length()>0){
                    category.setAge_estimate(tokens[3]);
                }
                if(tokens.length>=11 && tokens[4].length()>0){
                    category.setGender(tokens[4]);}
                if(tokens.length>=11 && tokens[1].length()>0){
                    category.setReported_on(tokens[1]);}
                if(tokens.length>=11 && tokens[8].length()>0){
                    category.setStatus(tokens[8]);}
                deceased_persons.add(category);
                i++;


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
          return deceased_persons;

    }

    private  class DbAsyn extends AsyncTask<Void,Void,Void>{

        public DbAsyn() {

        }



        @Override
        protected Void doInBackground(Void... voids) {
         //   Log.d("uuuu", "doInBackground: ");

            DeceasedPersons= getcsv();
            storeinDatabase(DeceasedPersons);


            return null;


        }
    }


}