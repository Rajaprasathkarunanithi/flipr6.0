package com.rajaprasath.covid.util;

public class Util {


    //Database related items
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "deceased_db";
    public static final String TABLE_NAME = "Deceased";

    //Contacts table columns names
    public static final String PATIENT_ID = "id";
    public static final String REPORTED_ON = "date";
    public static final String AGE_ESTIMATED = "age_estimated";
    public static final String GENDER="gender";
    public static final String STATE="state";
    public static final String STATUS="status";
}
