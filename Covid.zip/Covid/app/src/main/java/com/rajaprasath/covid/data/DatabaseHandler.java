package com.rajaprasath.covid.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.rajaprasath.covid.R;
import com.rajaprasath.covid.model.Category;
import com.rajaprasath.covid.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {


    public DatabaseHandler(Context context ) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    //We create our table
    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_DECEASED_TABLE = "CREATE TABLE " + Util.TABLE_NAME + "("
                + Util.PATIENT_ID + " INTEGER," + Util.STATE + " TEXT," + Util.AGE_ESTIMATED + " TEXT,"
                + Util.GENDER + " TEXT," + Util.REPORTED_ON + " TEXT,"
                + Util.STATUS + " TEXT" + ")";
        db.execSQL(CREATE_DECEASED_TABLE); //creating our table

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = String.valueOf(R.string.db_drop);
        db.execSQL(DROP_TABLE, new String[]{Util.DATABASE_NAME});

        onCreate(db);


    }



    public void addPerson(Category category){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Util.PATIENT_ID,category.getPatient_id());
        values.put(Util.STATE,category.getState());
        values.put(Util.REPORTED_ON,category.getReported_on());
        values.put(Util.AGE_ESTIMATED,category.getAge_estimate());
        values.put(Util.GENDER,category.getGender());
        values.put(Util.STATUS,category.getStatus());
        db.insert(Util.TABLE_NAME, null, values);
        db.close();
    }



    public List<Category> getAllPerson(){
        List<Category> personlist = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = "SELECT * FROM " + Util.TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst()) {
            do {

                Category category= new Category();
                category.setPatient_id(Integer.parseInt(cursor.getString(0)));
                category.setState(cursor.getString(1));
                category.setAge_estimate(cursor.getString(2));
                category.setGender(cursor.getString(3));
                category.setReported_on(cursor.getString(4));
                category.setStatus(cursor.getString(5));

                personlist.add(category);


            }while (cursor.moveToNext());
        }

        return personlist;
    }



    //Get contacts count
    public int getCount() {
        String countQuery = "SELECT * FROM " + Util.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        return cursor.getCount();

    }
}
