package com.rajaprasath.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.rajaprasath.covid.data.AsyncResponse;
import com.rajaprasath.covid.data.CoronaApi;
import com.rajaprasath.covid.model.Category;

import java.util.ArrayList;
import java.util.List;

public class ContactNHelpline extends AppCompatActivity {
    private TableLayout tl;
    private TableRow tr;
    private TextView state_name,helpline;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_n_helpline);

        CoronaApi coronaApi =new CoronaApi();
        tl=findViewById(R.id.contact_table);
        tl.setColumnStretchable(0,true);
        tl.setColumnStretchable(1,true);
        List<Category> contact_n_helpline=coronaApi.Contact_N_Helpline(this, new AsyncResponse() {
            @Override
            public void processFinished(ArrayList<Category> list) {
                for (Category category: list) {
                    tr=new TableRow(ContactNHelpline.this);
                    state_name= new TextView(ContactNHelpline.this);
                    helpline= new TextView(ContactNHelpline.this);
                    state_name.setText(category.getState());
                    state_name.setTextSize(15);
                    state_name.setGravity(Gravity.CENTER);
                    state_name.setBackgroundColor(Color.WHITE);
                    state_name.setPadding(1,1,1,1);
                    helpline.setText(category.getHelpline());
                    helpline.setTextSize(15);
                    helpline.setGravity(Gravity.CENTER);
                    helpline.setBackgroundColor(Color.WHITE);
                    helpline.setPadding(1,1,1,1);
                    tr.addView(state_name);
                    tr.addView(helpline);
                    tl.addView(tr);
                     Log.d("tag", "processFinished: " + category.getState() + " " + category.getHelpline());
                }
            }
        });



    }
}