package com.rajaprasath.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.rajaprasath.covid.data.AsyncResponse;
import com.rajaprasath.covid.data.CoronaApi;
import com.rajaprasath.covid.model.Category;

import java.util.ArrayList;
import java.util.List;

public class NotifNAdvisory extends AppCompatActivity {

    private TableLayout tl;
    private TableRow tr;
    private TextView date,title,link;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notif_n_advisory);

        CoronaApi coronaApi= new CoronaApi();
        tl=findViewById(R.id.notif_table);
        tl.setColumnStretchable(0,true);
        tl.setColumnStretchable(1,true);
        tl.setColumnStretchable(2,true);

        List<Category> notif_advis= coronaApi.Notif_N_Advisory(this, new AsyncResponse() {
            @Override
            public void processFinished(ArrayList<Category> list) {
                for(Category category: list){
                    tr= new TableRow(NotifNAdvisory.this);
                    date=new TextView(NotifNAdvisory.this);
                    title=new TextView(NotifNAdvisory.this);
                    link=new TextView(NotifNAdvisory.this);
                    date.setText(category.getDate());
                    date.setTextSize(15);
                    date.setGravity(Gravity.CENTER);
                    date.setBackgroundColor(Color.WHITE);
                    title.setText(category.getNotification_title());
                    title.setTextSize(15);
                    title.setGravity(Gravity.CENTER);
                    title.setBackgroundColor(Color.WHITE);
                    link.setText(category.getLink());
                    link.setTextSize(15);
                    link.setGravity(Gravity.CENTER);
                    link.setBackgroundColor(Color.WHITE);
                    tr.addView(date);
                    tr.addView(title);
                    tr.addView(link);
                    tl.addView(tr);
                    Log.d("tag", "processFinished: "+category.getDate()+"   "+ category.getNotification_title()+"  "+category.getLink());
                }
            }
        });
    }
}