package com.rajaprasath.covid.data;

import com.rajaprasath.covid.model.Category;

import java.util.ArrayList;
import java.util.List;

public interface AsyncResponse {
    public void processFinished(ArrayList<Category> list);

}
