package com.rajaprasath.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.rajaprasath.covid.data.AsyncResponse;
import com.rajaprasath.covid.data.CoronaApi;
import com.rajaprasath.covid.model.Category;

import java.util.ArrayList;
import java.util.List;

public class MedicalBeds extends AppCompatActivity {

    private TableLayout tl;
    private TableRow tr;
    private TextView state,name,city,type,admi_capacity,hospi_beds;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_beds);
        CoronaApi coronaApi= new CoronaApi();
        tl=findViewById(R.id.medicol_bed_table);
        List<Category> medicol_bed = coronaApi.Medicol_N_Beds(this, new AsyncResponse() {
            @Override
            public void processFinished(ArrayList<Category> list) {
                for (Category category : list){
                    tr=new TableRow(MedicalBeds.this);
                    state=new TextView(MedicalBeds.this);
                    name=new TextView(MedicalBeds.this);
                    city=new TextView(MedicalBeds.this);
                    type=new TextView(MedicalBeds.this);
                    admi_capacity=new TextView(MedicalBeds.this);
                    hospi_beds=new TextView(MedicalBeds.this);
                    state.setText(category.getState());
                    state.setTextSize(15);
                    state.setGravity(Gravity.CENTER);
                    state.setBackgroundColor(Color.WHITE);
                    name.setText(category.getInstitute_name());
                    name.setTextSize(15);
                    name.setGravity(Gravity.CENTER);
                    name.setBackgroundColor(Color.WHITE);
                    city.setText(category.getCity());
                    city.setTextSize(15);
                    city.setGravity(Gravity.CENTER);
                    city.setBackgroundColor(Color.WHITE);
                    type.setText(category.getType());
                    type.setTextSize(15);
                    type.setGravity(Gravity.CENTER);
                    type.setBackgroundColor(Color.WHITE);
                    admi_capacity.setText(String.valueOf(category.getAdmission_capacity()));
                    admi_capacity.setTextSize(15);
                    admi_capacity.setGravity(Gravity.CENTER);
                    admi_capacity.setBackgroundColor(Color.WHITE);
                    hospi_beds.setText(String.valueOf(category.getHospital_beds()));
                    hospi_beds.setTextSize(15);
                    hospi_beds.setGravity(Gravity.CENTER);
                    hospi_beds.setBackgroundColor(Color.WHITE);
                    tr.addView(state);
                    tr.addView(name);
                    tr.addView(city);
                    tr.addView(type);
                    tr.addView(admi_capacity);
                    tr.addView(hospi_beds);
                    tl.addView(tr);
                    //  Log.d("tag", "processFinished: "+category.getInstitute_name()+ "    "+ category.getHospital_beds());
                }
            }
        });
    }
}