package com.rajaprasath.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.rajaprasath.covid.data.AsyncResponse;
import com.rajaprasath.covid.data.CoronaApi;
import com.rajaprasath.covid.model.Category;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

private Button contact,notification,hospital_beds,Medical_college,deceasedPerson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contact=findViewById(R.id.contact);
        notification=findViewById(R.id.Notification);
        hospital_beds=findViewById(R.id.Hospital_beds);
        Medical_college=findViewById(R.id.Medical_college);
        deceasedPerson=findViewById(R.id.Graph);

        contact.setOnClickListener(this);
        notification.setOnClickListener(this);
        hospital_beds.setOnClickListener(this);
        Medical_college.setOnClickListener(this);
        deceasedPerson.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.contact:
                startActivity(new Intent(MainActivity.this,ContactNHelpline.class));
                break;
            case R.id.Notification:
                startActivity(new Intent(MainActivity.this,NotifNAdvisory.class));
                break;
            case R.id.Hospital_beds:
                startActivity(new Intent(MainActivity.this,HospitalBeds.class));
                break;
            case R.id.Medical_college:
                startActivity(new Intent(MainActivity.this,MedicalBeds.class));
                break;
            case R.id.Graph:
                startActivity(new Intent(MainActivity.this,Deceased.class));
                break;
        }
    }
}