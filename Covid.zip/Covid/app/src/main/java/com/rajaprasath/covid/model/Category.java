package com.rajaprasath.covid.model;

public class Category {
    private String state;
    private String helpline;
    private String date;
    private String notification_title;
    private String link;
    private int rural_hosp;
    private int rural_beds;
    private int urban_hosp;
    private int urban_beds;
    private int total_hosp;
    private int total_beds;
    private String institute_name;
    private String city;
    private String type;
    private int admission_capacity;
    private int hospital_beds;
    private int patient_id;
    private String reported_on;
    private String age_estimate;
    private String gender;
    private String status;


    public Category() {
    }

    public Category(String state, int patient_id, String reported_on, String age_estimate, String gender, String status) {
        this.state = state;
        this.patient_id = patient_id;
        this.reported_on = reported_on;
        this.age_estimate = age_estimate;
        this.gender = gender;
        this.status = status;
    }


    public Category(String state, String helpline, String date, String notification_title, String link, int rural_hosp, int rural_beds, int urban_hosp, int urban_beds, int total_hosp, int total_beds, String institute_name, String city, String type, int admission_capacity, int hospital_beds, int total_confirmed, int total_sample_tested) {
        this.state = state;
        this.helpline = helpline;
        this.date = date;
        this.notification_title = notification_title;
        this.link = link;
        this.rural_hosp = rural_hosp;
        this.rural_beds = rural_beds;
        this.urban_hosp = urban_hosp;
        this.urban_beds = urban_beds;
        this.total_hosp = total_hosp;
        this.total_beds = total_beds;
        this.institute_name = institute_name;
        this.city = city;
        this.type = type;
        this.admission_capacity = admission_capacity;
        this.hospital_beds = hospital_beds;

    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getHelpline() {
        return helpline;
    }

    public void setHelpline(String helpline) {
        this.helpline = helpline;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNotification_title() {
        return notification_title;
    }

    public void setNotification_title(String notification_title) {
        this.notification_title = notification_title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getRural_hosp() {
        return rural_hosp;
    }

    public void setRural_hosp(int rural_hosp) {
        this.rural_hosp = rural_hosp;
    }

    public int getRural_beds() {
        return rural_beds;
    }

    public void setRural_beds(int rural_beds) {
        this.rural_beds = rural_beds;
    }

    public int getUrban_hosp() {
        return urban_hosp;
    }

    public void setUrban_hosp(int urban_hosp) {
        this.urban_hosp = urban_hosp;
    }

    public int getUrban_beds() {
        return urban_beds;
    }

    public void setUrban_beds(int urban_beds) {
        this.urban_beds = urban_beds;
    }

    public int getTotal_hosp() {
        return total_hosp;
    }

    public void setTotal_hosp(int total_hosp) {
        this.total_hosp = total_hosp;
    }

    public int getTotal_beds() {
        return total_beds;
    }

    public void setTotal_beds(int total_beds) {
        this.total_beds = total_beds;
    }

    public String getInstitute_name() {
        return institute_name;
    }

    public void setInstitute_name(String institute_name) {
        this.institute_name = institute_name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAdmission_capacity() {
        return admission_capacity;
    }

    public void setAdmission_capacity(int admission_capacity) {
        this.admission_capacity = admission_capacity;
    }

    public int getHospital_beds() {
        return hospital_beds;
    }

    public void setHospital_beds(int hospital_beds) {
        this.hospital_beds = hospital_beds;
    }


    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public String getReported_on() {
        return reported_on;
    }

    public void setReported_on(String reported_on) {
        this.reported_on = reported_on;
    }

    public String getAge_estimate() {
        return age_estimate;
    }

    public void setAge_estimate(String age_estimate) {
        this.age_estimate = age_estimate;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


}
