package com.rajaprasath.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.rajaprasath.covid.data.AsyncResponse;
import com.rajaprasath.covid.data.CoronaApi;
import com.rajaprasath.covid.model.Category;

import java.util.ArrayList;
import java.util.List;

public class HospitalBeds extends AppCompatActivity {


    private TableLayout tl;
    private TableRow tr;
    private TextView state,ru_hosp,ru_bed,urb_hosp,urb_bed,total_hosp,total_bed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_beds);

        CoronaApi coronaApi= new CoronaApi();
        tl=findViewById(R.id.hospi_bed_table);
        tl.setColumnStretchable(0,true);
        tl.setColumnStretchable(1,true);
        tl.setColumnStretchable(2,true);
        tl.setColumnStretchable(3,true);
        tl.setColumnStretchable(4,true);
        tl.setColumnStretchable(5,true);
        tl.setColumnStretchable(6,true);
        List<Category> hosp_bed= coronaApi.Hosp_N_Beds(this, new AsyncResponse() {
            @Override
            public void processFinished(ArrayList<Category> list) {
                for(Category category: list){

                    tr= new TableRow(HospitalBeds.this);
                    state=new TextView(HospitalBeds.this);
                    ru_hosp=new TextView(HospitalBeds.this);
                    ru_bed=new TextView(HospitalBeds.this);
                    urb_hosp=new TextView(HospitalBeds.this);
                    urb_bed=new TextView(HospitalBeds.this);
                    total_hosp=new TextView(HospitalBeds.this);
                    total_bed=new TextView(HospitalBeds.this);
                    state.setText(category.getState());
                    state.setTextSize(15);
                    state.setGravity(Gravity.CENTER);
                    state.setBackgroundColor(Color.WHITE);
                    ru_hosp.setText(String.valueOf(category.getRural_hosp()));
                    ru_hosp.setTextSize(15);
                    ru_hosp.setGravity(Gravity.CENTER);
                    ru_hosp.setBackgroundColor(Color.WHITE);

                    ru_bed.setText(String.valueOf(category.getRural_beds()));
                    ru_bed.setTextSize(15);
                    ru_bed.setGravity(Gravity.CENTER);
                    ru_bed.setBackgroundColor(Color.WHITE);
                    urb_hosp.setText(String.valueOf(category.getUrban_hosp()));
                    urb_hosp.setTextSize(15);
                    urb_hosp.setGravity(Gravity.CENTER);
                    urb_hosp.setBackgroundColor(Color.WHITE);
                    urb_bed.setText(String.valueOf(category.getUrban_beds()));
                    urb_bed.setTextSize(15);
                    urb_bed.setGravity(Gravity.CENTER);
                    urb_bed.setBackgroundColor(Color.WHITE);
                    total_hosp.setText(String.valueOf(category.getTotal_hosp()));
                    total_hosp.setTextSize(15);
                    total_hosp.setGravity(Gravity.CENTER);
                    total_hosp.setBackgroundColor(Color.WHITE);
                    total_bed.setText(String.valueOf(category.getTotal_beds()));
                    total_bed.setTextSize(15);
                    total_bed.setGravity(Gravity.CENTER);
                    total_bed.setBackgroundColor(Color.WHITE);


                    tr.addView(state);
                    tr.addView(ru_hosp);
                    tr.addView(ru_bed);
                    tr.addView(urb_hosp);
                    tr.addView(urb_bed);
                    tr.addView(total_hosp);
                    tr.addView(total_bed);
                    tl.addView(tr);




                    Log.d("tag", "processFinished: "+ category.getRural_hosp() + "    "+  category.getTotal_beds());
                }
            }
        });
    }
}